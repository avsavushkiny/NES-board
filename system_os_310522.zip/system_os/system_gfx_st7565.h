#pragma once

#include <Arduino.h>
#include <U8g2lib.h>
#include <SPI.h>
#include "system.h"
#include "system_map_xbmp.h"

U8G2_ST7565_ERC12864_F_4W_SW_SPI u8g2(U8G2_R0, 18, 19, 17, 16, 20);

unsigned long previousMillis = 0;
const long interval = 300;

class Gfx
{
  private:
  public:
    void screen()
    {
      u8g2.begin();
      u8g2.setContrast(0);
      sys.backlight(true);
    }

    void renderCatMessage( void (*draw_fn)(String, String, String, String),
                           String a, String b, String c, String d )
    {
      uint32_t time;
      time = millis() + 10;

      do {
        u8g2.clearBuffer();
        draw_fn(a, b, c, d);
        u8g2.sendBuffer();
      } while ( millis() < time );
    }

    void renderMessage( void (*draw_fn)(String, String),
                        String a, String b )
    {
      uint32_t time;
      time = millis() + 10;

      do {
        u8g2.clearBuffer();
        draw_fn(a, b);
        u8g2.sendBuffer();
      } while ( millis() < time );
    }

    void renderPage( void (*draw_fn)(void) )
    {
      uint32_t time;
      time = millis() + 10;

      do {
        u8g2.clearBuffer();
        draw_fn();
        u8g2.sendBuffer();
      } while ( millis() < time );
    }
};

Gfx gfx;

void messageHelloCat(String text1, String text2, String text3, String text4)
{
  u8g2.drawXBMP(2, 3, diaFrameHello_w, diaFrameHello_h, diaFrameHello);
  u8g2.drawXBMP(105, 45, nes_cat_w, nes_cat_h, nes_cat);
  u8g2.drawHLine(102, 59, 21);

  u8g2.setFont(u8g2_font_6x10_tr);
  u8g2.setCursor(9, 14);
  u8g2.print(text1);
  u8g2.setCursor(9, 24);
  u8g2.print(text2);
  u8g2.setCursor(9, 34);
  u8g2.print(text3);

  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval)
  {
    previousMillis = currentMillis;
  }
  else
  {
    u8g2.setCursor(20, 52);
    u8g2.print(text4);
  }
}

void messageBottom(String text1, String text2)
{
  u8g2.drawFrame(0, 39, 128, 2);
  u8g2.setFont(u8g2_font_6x10_tr);
  u8g2.setCursor(3, 50);
  u8g2.print(text1);
  u8g2.setCursor(3, 60);
  u8g2.print(text2);
}

bool drawCursor(bool stateCursor)
{
  if (stateCursor == true)
  {
    u8g2.setDrawColor(2);
    u8g2.setBitmapMode(1);
    u8g2.drawXBMP(sys.joi0x(), sys.joi0y(), cursorOne_w, cursorOne_h, cursorOne);
    return true;
  }
  else return false;
}

void messageDiaFrameBottom(String text1, String text2, String text3)
{
  u8g2.drawXBMP(0, 32, diaFrameBottom_w, diaFrameBottom_h, diaFrameBottom);
  //u8g2.drawXBMP(105, 45, nes_cat_w, nes_cat_h, nes_cat);
  //u8g2.drawHLine(102, 59, 21);

  u8g2.setFont(u8g2_font_6x10_tr);
  u8g2.setCursor(5, 50);
  u8g2.print(text1);
  u8g2.setCursor(5, 60);
  u8g2.print(text2);

  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval)
  {
    previousMillis = currentMillis;
  }
  else
  {
    u8g2.setCursor(98, 50);
    u8g2.print(text3);
  }
}
