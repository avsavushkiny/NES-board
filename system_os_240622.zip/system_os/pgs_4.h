/*
 *  info page
 */
/*
#include <Arduino.h>
#include <U8g2lib.h>
#include <SPI.h>
#include "system_gfx_st7565.h"

void drawPgs4();

void renderPgs4()
{
  uint32_t time;
  time = millis() + 10;

  do {
    u8g2.clearBuffer();
    drawPgs4();
    u8g2.sendBuffer();
  } while ( millis() < time );
}

void drawPgs4()
{
//messageTwo(0, 0,  "qwertyuiopasdfghjkl", "");
  messageTwo(0, 10, "Portable console", "");
  messageTwo(0, 20, "NES OS v1.1 090622", "");
  messageTwo(0, 30, "Game pack v1.0", "");
  messageTwo(0, 40, "", "");
  messageTwo(0, 50, "@avsavushkiny", "");
  messageTwo(0, 60, "github / 2022", "");
}*/
